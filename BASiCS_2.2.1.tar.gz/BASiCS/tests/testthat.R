library(testthat)
library(BASiCS)

test_check("BASiCS")
